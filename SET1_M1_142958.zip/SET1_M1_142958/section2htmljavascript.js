function validate(){
	var customerNumber = frm1.txtNumber.value;
	var CustomerName = frm1.txtName.value;
	var Email = frm1.txtEmail.value;
	var UnitNo = frm1.txtUnit.value;
	var TotalChargeAmount	=	getTotalCharge(UnitNo);

	alert("Customer No :	"+customerNumber+
	"\nCustomer Name	:	"+CustomerName+
	"\nEmail Address	:"+Email+
	"\nNumber Of Units	:"+UnitNo+
	"\nTotal Electricity Charges	:"+TotalChargeAmount);
}


function getTotalCharge(UnitNo){
	
	if(UnitNo>=0 && UnitNo<=100){
		var charge	=	2.80;
	}
	else if(UnitNo>100 && UnitNo<=200 ){
		var charge	=	3.90;
	}
	else if(UnitNo>200){
		var charge	=4.50;
	}
	var totalCharge	=	UnitNo	*	charge;
	return(totalCharge);
}
	